# Keep this project simple; no custom shrinking rules are required.
